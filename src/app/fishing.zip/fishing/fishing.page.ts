import { Component, OnInit } from '@angular/core';

import {ToastController,LoadingController,Platform} from "@ionic/angular";
import firebase from 'firebase';

@Component({
  selector: 'app-fishing',
  templateUrl: './fishing.page.html',
  styleUrls: ['./fishing.page.scss'],
  
})
export class FishingPage implements OnInit {
  obj:any={};
  keys:any[]=[];
  location:string="";
  comments:string="";
  appname:any="horgaszvip";
  config:any={
  //   apiKey: "AIzaSyCNgYRtLXEZImH_JHldDWfEx9BlbLLtnhc",
  //  // authDomain: "gt06-59e86.firebaseapp.com",
  //  databaseURL: "https://trackonmap-b0571.firebaseio.com/",
  //  storageBucket: "trackonmap-b0571.appspot.com"
  apiKey: "AIzaSyBU72xlQbf4ZWONW6l2S_KDeutKmbshphk",
 // authDomain: "horgaszvip.firebaseapp.com",
  databaseURL: "https://ionic-fcm-9a97b.firebaseio.com/",
  // projectId: "horgaszvip",
  // storageBucket: "horgaszvip.appspot.com",
  // messagingSenderId: "544964973382",
  // appId: "1:544964973382:web:c8b457d16e0d00b5d88b47"
   }
  constructor(private loader:LoadingController,private toast:ToastController,private platform:Platform)
  {
    this.platform.ready().then(()=>{
      if(firebase.apps.length == 0)
 
      {
   firebase.initializeApp(this.config);
      }
 
    })
  }

  ngOnInit() {
    this.getData();
  }
  getMetaInfo()
  {
    var ref = this;
    this.getMetaInfoTemp(function(data)
    {
      if(data)
      {
       ref.location = data.location;
       ref.comments = data.comments;
      }
    })
  }
  getData()
  {
    let ref = this;
    this.loader.create({
      message:"please wait..."
    }).then((ele)=>{
  
    ele.present();
    this.getDataTemp(function(data)
    {
      ele.dismiss();
      if(data)
      {
      console.log(JSON.stringify(data));
      ref.keys = Object.keys(data);
      ref.obj = data;
      ref.getMetaInfo();
      //alert(JSON.stringify(keys));
    //   let arr = [];
    //   for(var i = 0;i<keys.length;i++)
    //   {
    //     console.log(data[keys[i]]);
    //    arr = arr.concat(data[keys[i]]);
    //   }
    //  // alert(JSON.stringify(arr));
    //   if(arr.length > 0)
    //   {
    //     ref.fieldArray = [];
    //     ref.fieldArray = arr;
    //   }
      }
    })
  })
  
  }

  getMetaInfoTemp(fn)
  {
   firebase.database().ref(this.appname+"/metainfo").once('value').then(function (snapshot) {
     let data =  snapshot.val();
     fn(data);

   });
    
  }

  getDataTemp(fn)
   {
    
    firebase.database().ref(this.appname + "/data/").once('value').then(function (snapshot) {
        let data =  snapshot.val();
        fn(data);
   
      });
   }

}
